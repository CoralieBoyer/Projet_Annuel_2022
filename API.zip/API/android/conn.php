<?php
$db_name = "sac_fidelity";
$username = "root";
$password = "";
$servename = "127.0.0.1";
$conn = mysqli_connect($servename ,$username ,$password ,$db_name );
mysqli_set_charset($conn ,"utf-8");

?>